﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 3/17/2022
 * Time: 9:11 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Kalkulator
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		
		void TambahClick(object sender, EventArgs e)
		{
			if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
			{
				MessageBox.Show(" Angka 1 dan Angka 2 tidak boleh kosong ");
			} else{
				int a,b,c;
				a = int.Parse(this.textBox1.Text);
				b = int.Parse(this.textBox2.Text);
				c = a + b;
				this.label4.Text = c.ToString();
			}
		}
		
		void KurangClick(object sender, EventArgs e)
		{
				if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
			{
				MessageBox.Show(" Angka 1 dan Angka 2 tidak boleh kosong ");
			} else{
				int a,b,c;
				a = int.Parse(this.textBox1.Text);
				b = int.Parse(this.textBox2.Text);
				c = a - b;
				this.label4.Text = c.ToString();
			}				
		}
		
		void KaliClick(object sender, EventArgs e)
		{
				if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
			{
				MessageBox.Show(" Angka 1 dan Angka 2 tidak boleh kosong ");
			} else{
				int a,b,c;
				a = int.Parse(this.textBox1.Text);
				b = int.Parse(this.textBox2.Text);
				c = a * b;
				this.label4.Text = c.ToString();
			}			
		}
		
		void BagiClick(object sender, EventArgs e)
		{
			if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
			{
				MessageBox.Show(" Angka 1 dan Angka 2 tidak boleh kosong ");
			} 
			    else{
				int a,b,c;
				a = int.Parse(this.textBox1.Text);
				b = int.Parse(this.textBox2.Text);
				c = a / b;
				this.label4.Text = c.ToString();
			}			
		}
		
		void HapusClick(object sender, EventArgs e)
		{
			textBox1.Clear();
			textBox2.Clear();
			label4.Text = "";
		}
	}
}
